package factura;

import java.util.Locale;
import java.util.Scanner;
import java.util.InputMismatchException;

public class AppFactura {

    public static void main(String[] args) {
        int conf2=0;
        int conf;
        double precioTotal=0;

        System.out.println("_________________________________________________________" );
        System.out.println("Bienvenido a DigitalMK,ingrese la siguiente informacion: ");
        System.out.println("_________________________________________________________\n" );

        Factura factu=new Factura();
        factu.llenarDatosFactura();
        Scanner sc=new Scanner(System.in);
        sc.useLocale(Locale.US);


        one:
        do{
            factu.numFactura++;
            System.out.println("\n----------------------------------------------------------------" );
            Cliente cliente=new Cliente();
            cliente.ingresarDatos();
            System.out.println("----------------------------------------------------------------\n" );
            System.out.println("Ahora ,realize su compra :D:");
            int numProd=0;
            System.out.println("¿Cuantos productos va a comprar? El limite maximo por factura es 5 items.");
            numProd=sc.nextInt();

            Producto prod1=new Producto();
            Producto prod2=new Producto();
            Producto prod3=new Producto();
            Producto prod4=new Producto();
            Producto prod5=new Producto();


            switch(numProd){
                case (1):
                    prod1.llenarProductos();
                    prod1.calcularIva();
                    prod1.valorProductos();

                    System.out.println("Su factura se imprimira,ahora:\n");
                    factu.imprimirEncabezado();
                    cliente.imprimirDatosCliente();
                    prod1.imprimirProduc();
                    System.out.println("--------------------------------------------------------------------------------------------" );
                    precioTotal=prod1.precioFinal;
                    precioTotal=Math.round(precioTotal*100.0)/100.0;
                    System.out.println("TOTAL                                                                            "+precioTotal);
                    System.out.println("================================================================================================" );
                    System.out.println("================================================================================================" );

                    break;
                case (2):
                    prod1.llenarProductos();
                    prod1.calcularIva();
                    prod1.valorProductos();
                    prod2.llenarProductos();
                    prod2.calcularIva();
                    prod2.valorProductos();

                    System.out.println("Su factura se imprimira,ahora:\n");
                    factu.imprimirEncabezado();
                    cliente.imprimirDatosCliente();
                    prod1.imprimirProduc();
                    prod2.imprimirProduc();
                    System.out.println("--------------------------------------------------------------------------------------------" );
                    precioTotal=prod1.precioFinal+prod2.precioFinal;
                    precioTotal=Math.round(precioTotal*100.0)/100.0;
                    System.out.println("TOTAL                                                                            "+precioTotal);
                    System.out.println("================================================================================================" );
                    System.out.println("================================================================================================" );

                    break;
                case (3):
                    prod1.llenarProductos();
                    prod1.calcularIva();
                    prod1.valorProductos();
                    prod2.llenarProductos();
                    prod2.calcularIva();
                    prod2.valorProductos();
                    prod3.llenarProductos();
                    prod3.calcularIva();
                    prod3.valorProductos();

                    System.out.println("Su factura se imprimira,ahora:\n");
                    factu.imprimirEncabezado();
                    cliente.imprimirDatosCliente();
                    prod1.imprimirProduc();
                    prod2.imprimirProduc();
                    prod3.imprimirProduc();
                    System.out.println("--------------------------------------------------------------------------------------------" );
                    precioTotal=prod1.precioFinal+prod2.precioFinal+prod3.precioFinal;
                    precioTotal=Math.round(precioTotal*100.0)/100.0;
                    System.out.println("TOTAL                                                                            "+precioTotal);
                    System.out.println("================================================================================================" );
                    System.out.println("================================================================================================" );
                    break;
                case (4):
                    prod1.llenarProductos();
                    prod1.calcularIva();
                    prod1.valorProductos();
                    prod2.llenarProductos();
                    prod2.calcularIva();
                    prod2.valorProductos();
                    prod3.llenarProductos();
                    prod3.calcularIva();
                    prod3.valorProductos();
                    prod4.llenarProductos();
                    prod4.calcularIva();
                    prod4.valorProductos();

                    System.out.println("Su factura se imprimira,ahora:\n");
                    factu.imprimirEncabezado();
                    cliente.imprimirDatosCliente();
                    prod1.imprimirProduc();
                    prod2.imprimirProduc();
                    prod3.imprimirProduc();
                    prod4.imprimirProduc();
                    System.out.println("--------------------------------------------------------------------------------------------" );
                    precioTotal=prod1.precioFinal+prod2.precioFinal+prod3.precioFinal+prod4.precioFinal;
                    precioTotal=Math.round(precioTotal*100.0)/100.0;
                    System.out.println("TOTAL                                                                            "+precioTotal);
                    System.out.println("================================================================================================" );
                    System.out.println("================================================================================================" );
                    break;
                case (5):
                    prod1.llenarProductos();
                    prod1.calcularIva();
                    prod1.valorProductos();
                    prod2.llenarProductos();
                    prod2.calcularIva();
                    prod2.valorProductos();
                    prod3.llenarProductos();
                    prod3.calcularIva();
                    prod3.valorProductos();
                    prod4.llenarProductos();
                    prod4.calcularIva();
                    prod4.valorProductos();
                    prod5.llenarProductos();
                    prod5.calcularIva();
                    prod5.valorProductos();

                    System.out.println("Su factura se imprimira,ahora:\n");
                    factu.imprimirEncabezado();
                    cliente.imprimirDatosCliente();
                    prod1.imprimirProduc();
                    prod2.imprimirProduc();
                    prod3.imprimirProduc();
                    prod4.imprimirProduc();
                    prod5.imprimirProduc();
                    System.out.println("--------------------------------------------------------------------------------------------" );
                    precioTotal=prod1.precioFinal+prod2.precioFinal+prod3.precioFinal+prod4.precioFinal+prod5.precioFinal;
                    precioTotal=Math.round(precioTotal*100.0)/100.0;
                    System.out.println("TOTAL                                                                            "+precioTotal);
                    System.out.println("================================================================================================" );
                    System.out.println("================================================================================================" );
                    break;
                default:
                    System.out.println("El valor ingresado no es valido,ingrese correctamente");
            }


            System.out.println("¿Desea generar otra factura? Ingrese 0 para confirmar y -1 para cerrar el programa");
            conf2=sc.nextInt();

            if(conf2 == 0){
                continue one;
            }

        }while(conf2!=-1);


    }
}



        //precio+=prod.valorProductos(prod.cantidad, prod.valorUni,prod.iva,prod.precioFinal);
/*
        boolean seguir=true;
        while(seguir==true){
            try {
                System.out.println("¿Desea agregar otro producto? Ingrese 0 para comprar otro producto,1 para concluir la compra");//genera nuevo producto
                conf= sc.nextInt();
                if(conf==0){
                    seguir = false;
                    sc.nextLine();
                }
                if(conf==1){//genera una nueva factura
                    System.out.println("Gracias por su compra,se le presentara su factura");
                    System.out.println("\n========================FACTURA==============================");
                    System.out.println(factu.nomTienda+"\n"+factu.ruc+"\n"+factu.autSRI+"\n"+factu.direccion);
                    //System.out.println("ID/RUC:"+cliente.id()+"\n"+"NOMBRE:"+cliente.nombre()+"\n"+"DIRECCION:"+cliente.direccion()+"\n"+"TELEFONO:"+cliente.numCel());
                    System.out.println("PRECIO FINAL ="+precio);
                    System.out.println("==============================================================\n\n");
                    seguir = false;

                }
                break;
            } catch (InputMismatchException ex){
                System.out.println("\nError,ingrese los valores en numeros");// si tiene caracterres salta el error
            } catch (IndexOutOfBoundsException exception){
                System.out.println("\nError,este rango no esta definido");// si no esta en el rango definido salta error
            }

        }
    }
}
        /*confirmacion para generar otra factura o un nuevo producto

                /*System.out.println("¿Termino las ventas de hoy?. Ingrese -1 para terminar el programa");

            }while(conf2!=-1);
            sc.close();*/