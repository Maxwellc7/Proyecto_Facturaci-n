package factura;

import java.util.Locale;
import java.util.Scanner;

public class AppFactura {

    public static void main(String[] args) {
        int num=50;
        int conf;
        int numClientes=100;
        int conf2=0;
        double precio=0;

        one:
            for(int i=0;i<numClientes;i++){ //bucle para generar facturas

                System.out.println("==============================================================" );
                System.out.println("Bienvenido a DigitalMK,ingrese la siguiente informacion: ");
                Factura factu=new Factura();

                Scanner sc=new Scanner(System.in);
                sc.useLocale(Locale.US);
                Cliente cliente=new Cliente();
                System.out.print("Introduzca el nombre del cliente: ");
                cliente.nombre=sc.nextLine();
                System.out.print("Introduzca la cedula de identidad o ruc del cliente:");
                cliente.id=sc.nextLine();
                System.out.print("Introduzca la direccion de domocilio del cliente:");
                cliente.direccion=sc.nextLine();
                System.out.print("Introduzca el numero de contacto del cliente:");
                cliente.numCel=sc.nextLine();
                System.out.print("Introduzca el email del cliente:");
                cliente.email=sc.nextLine();


                two: //Bucle para ingresar productos
                for(int j = 0; j < num; j++) {
                        Producto prod=new Producto();

                        System.out.println("Realice su compra");
                        System.out.println("Ingrese el nombre del producto: ");
                        prod.nombre=sc.nextLine();

                        System.out.println("Ingrese el precio del producto:");
                        prod.valorUni=sc.nextDouble();

                        System.out.println("Ingrese cuantos productos llevara de esta especie: ");
                        prod.cantidad=sc.nextInt();

                        prod.calcularIva(prod.valorUni);
                        prod.valorProductos(prod.cantidad, prod.precioFinal);
                        precio+=prod.precioFinal;

                        //confirmacion para generar otra factura o un nuevo producto
                        System.out.println("¿Desea agregar otro producto? Ingrese 0 para comprar otro producto,1 para concluir la compra");//genera nuevo producto
                        conf= sc.nextInt();
                        if(conf==0){
                            continue two;
                        }
                        if(conf==1){//genera una nueva factura
                            System.out.println("Gracias por su compra,se le presentara su factura");
                            System.out.println("==============================================================");
                            System.out.println("Precio Final ="+precio);
                            continue one;

                        }
                }
                System.out.println("¿Concluyó la venta de hoy?");

            }
    }

}

